# This should contain the make command to generate executable name 'solution' using Makefile
# The 'solution' file should be in the bin directory
# Please use the evaluation script as `bash script.sh` to compile your code
