/**************************************************************************
 *  $Id$
 *  Release $Name$
 *
 *  File:	NodeType.h
 *
 *  Purpose:	Header file for NodeType
 *
 *  Author:	CS21M037, N Kausik
 *
 *  Created:    01-11-2021
 *
 *  Last modified: 
 *
 *  Bugs:	
 *
 *  Change Log:	
 *  
 *
 **************************************************************************/

#ifndef NODETYPE_H
#define NODETYPE_H
#include <iostream>
using namespace std;

typedef int NodeType;
#endif

/**************************************************************************
 * $Log$
 * 
 * End:
 *                        End of NodeType.h
 **************************************************************************/