/**************************************************************************
 *  $Id$
 *  Release $Name$
 *
 *  File:	WeightType.h
 *
 *  Purpose:	Header file for WeightType
 *
 *  Author:	CS21M037, N Kausik
 *
 *  Created:    01-11-2021
 *
 *  Last modified: 
 *
 *  Bugs:	
 *
 *  Change Log:	
 *  
 *
 **************************************************************************/

#ifndef WEIGHTTYPE_H
#define WEIGHTTYPE_H
#include <iostream>
using namespace std;

typedef int WeightType;
#endif

/**************************************************************************
 * $Log$
 * 
 * End:
 *                        End of WeightType.h
 **************************************************************************/